package exercises

// Define the class
// with a private constructor!
class User private (val name: String, val id: Int):
  override def toString: String = s"User($name, id=$id)"

// Companion object
object User:
  // private counter to generate unique IDs
  private var counter: Int = 0

  // factory method to create new users
  def apply(name: String): User =
    counter += 1
    new User(name, counter)

// Demo
object ExerciseCompanion extends App:
  val u1 = User("Alice")   // no `new`
  val u2 = User("Bob")

  println(u1)  // e.g., User(Alice, id=1)
  println(u2)  // e.g., User(Bob, id=2)
