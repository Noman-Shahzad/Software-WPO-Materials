package exercises

abstract class Car:
    type Engine <: GeneralEngine
    type ExteriorMaterial <: AbstractMaterial

    def constructEngine: Engine
    def constructMaterial: ExteriorMaterial

    abstract class AbstractMaterial:
        def applyExternalMaterial(material: String): String

    abstract class GeneralEngine:
        def putEngine(engine: String): String

        def isOfType(engine: Engine): Boolean

class CombustionCars extends Car:
    type Engine = CombustionEngine
    type ExteriorMaterial = MetalMaterial

    override def constructEngine: CombustionEngine = new CombustionEngine
    override def constructMaterial: MetalMaterial = new MetalMaterial

    class MetalMaterial extends AbstractMaterial {
        override def applyExternalMaterial(material: String): String = s"The material is $material"
    }

    class CombustionEngine extends GeneralEngine {
        override def putEngine(engine: String): String = s"The engine is $engine"

        override def isOfType(engine: Engine): Boolean = engine.isInstanceOf[CombustionEngine]
    }

object CombustionCars:
    val newCars: CombustionCars = new CombustionCars
    val newEngines: newCars.CombustionEngine = newCars.constructEngine
    newEngines.putEngine("Combustion")

    val newMaterials: newCars.MetalMaterial = newCars.constructMaterial
    newMaterials.applyExternalMaterial("Metal")

class ElectricCars extends Car:
    type Engine = ElectricEngine
    type ExteriorMaterial = PlasticMaterial

    override def constructEngine: ElectricEngine = new ElectricEngine
    override def constructMaterial: PlasticMaterial = new PlasticMaterial

    class PlasticMaterial extends AbstractMaterial {
        override def applyExternalMaterial(material: String): String = s"The material is $material"
    }

    class ElectricEngine extends GeneralEngine {
        override def putEngine(engine: String): String = s"The engine is $engine"

        override def isOfType(engine: Engine): Boolean = engine.isInstanceOf[ElectricEngine]
    }

object ElectricCars:
    val newCars: ElectricCars = new ElectricCars
    val newEngines: newCars.ElectricEngine = newCars.constructEngine
    newEngines.putEngine("Electric")

    val newMaterials: newCars.PlasticMaterial = newCars.constructMaterial
    newMaterials.applyExternalMaterial("Plastic")


object Exercise2_Solution extends App:
    // Combustion Cars family
    val ferrari = CombustionCars.newCars
    val ferrariEngine = CombustionCars.newEngines
    val ferrariMaterial = CombustionCars.newMaterials

    val mercedes = CombustionCars.newCars
    val mercedesEngine = CombustionCars.newEngines
    val mercedesMaterial = CombustionCars.newMaterials

    assert(ferrariEngine.isOfType(mercedesEngine))
    println("Same Combustion Engines")

    // Electric Cars family
    val tesla = ElectricCars.newCars
    val teslaEngine = ElectricCars.newEngines
    val teslaMaterial = ElectricCars.newMaterials

    val mercedesElectric = ElectricCars.newCars
    val mercedesElectricEngine = ElectricCars.newEngines
    val mercedesElectricMaterial = ElectricCars.newMaterials

    assert(mercedesElectricEngine.isOfType(teslaEngine))
    println("Same Electrical Engines")

    // Comparison in different families
    // assert(mercedesElectricEngine.isOfType(mercedesEngine))
    // Error at compile time, not at runtime
