package exercises

import scala.collection.mutable.ArrayBuffer
import scala.compiletime.uninitialized

trait ListenerWrapper:
    type SourceType <: Source
    type EventType <: Event
    type ListenerType <: Listener

    trait Source:
        this: SourceType =>

        private val listeners = new ArrayBuffer[ListenerType]

        def add(l: ListenerType): Unit = listeners += l

        def remove(l: ListenerType): Unit = listeners -= l

        def fire(e: EventType): Unit =
            e.source = this
            listeners.foreach(_.occurred(e))

    trait Event:
        var source: SourceType = uninitialized

    trait Listener:
        def occurred(e: EventType): Unit

object ButtonWrapper extends ListenerWrapper:
    type SourceType = Button
    type EventType = ButtonEvent
    type ListenerType = ButtonListener

    class Button extends Source:
        def click(): Unit = fire(new ButtonEvent)

    class ButtonEvent extends Event

    trait ButtonListener extends Listener

object Exercise1_Solution extends App:
    import ButtonWrapper.*

    val button: Button = new Button
    button.add(new ButtonListener {
        override def occurred(e: ButtonEvent): Unit = println(s"$e from ${e.source}")
    })

//    button.add((e: ButtonEvent) => println(s"$e from ${e.source}"))
    button.click()
