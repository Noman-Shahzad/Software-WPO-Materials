package exercises

// Abstract type member version
trait Storage:
  type Item
  def put(item: Item): Unit
  def get: Option[Item]

// StringStorage using abstract type member
class StringStorage extends Storage:
  type Item = String
  private var items: List[String] = Nil
  def put(item: String): Unit = items = item :: items
  def get: Option[String] = items.headOption

// IntStorage using abstract type member
class IntStorage extends Storage:
  type Item = Int
  private var items: List[Int] = Nil
  def put(item: Int): Unit = items = item :: items
  def get: Option[Int] = items.headOption

// Generic storage using type parameter
class GenericStorage[T]:
  private var items: List[T] = Nil
  def put(item: T): Unit = items = item :: items
  def get: Option[T] = items.headOption

object ExerciseAbstractType extends App:
  // Usage examples
  val sStore = new StringStorage
  sStore.put("hello")
  println(sStore.get) // Some("hello")

  val iStore = new IntStorage
  iStore.put(42)
  println(iStore.get) // Some(42)

  val gStore = new GenericStorage[Double]
  gStore.put(3.14)
  println(gStore.get) // Some(3.14)
