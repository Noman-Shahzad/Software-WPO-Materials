// Step 1: Abstract class
abstract class PaymentMethod(val currency: String, val transactionId: String):
  def pay(amount: Double): Unit

  def receipt(amount: Double): String =
    s"Transaction $transactionId: Paid $$${amount} $currency"

// Step 2: Concrete implementations
class CreditCardPayment(currency: String, transactionId: String, cardNumber: String)
  extends PaymentMethod(currency, transactionId):

  override def pay(amount: Double): Unit =
    println(s"Processing credit card $cardNumber...")
    println(receipt(amount))

class PayPalPayment(currency: String, transactionId: String, email: String)
  extends PaymentMethod(currency, transactionId):

  override def pay(amount: Double): Unit =
    println(s"Processing PayPal account $email...")
    println(receipt(amount))

// Step 3: Behavior traits
trait Logging extends PaymentMethod:
  abstract override def pay(amount: Double): Unit =
    println(s"[LOG] Attempting payment of $$${amount} ${currency}")
    super.pay(amount)

trait FraudDetection extends PaymentMethod:
  abstract override def pay(amount: Double): Unit =
    if amount > 1000 then println("[FRAUD WARNING] High-value transaction detected!")
    else super.pay(amount)

// Step 4: Demo
object ExerciseTraits extends App:
  val cc = new CreditCardPayment("USD", "TX123", "1234-5678-9012-3456")
    with Logging with FraudDetection

  val pp = new PayPalPayment("EUR", "TX456", "user@example.com")
    with FraudDetection with Logging

  cc.pay(500)
  cc.pay(2000)

  pp.pay(1200)
