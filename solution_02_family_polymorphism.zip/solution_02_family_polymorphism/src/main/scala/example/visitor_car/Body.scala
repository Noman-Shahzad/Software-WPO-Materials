package example.visitor_car

case class Body() extends CarElement:
  override def accept(visitor: CarElementVisitor): Unit = visitor.visit(this)
