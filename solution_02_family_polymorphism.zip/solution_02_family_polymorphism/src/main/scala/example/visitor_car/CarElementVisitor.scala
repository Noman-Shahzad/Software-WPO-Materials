package example.visitor_car

trait CarElementVisitor:
  def visit(wheel: Wheel): Unit
  def visit(body: Body): Unit
  def visit(engine: Engine): Unit
  def visit(car: Car): Unit
