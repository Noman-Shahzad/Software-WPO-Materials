package example.visitor_car

case class CarElementDoVisitor() extends CarElementVisitor:
  def visit(wheel: Wheel): Unit = println(s"Kicking my ${wheel.getName} wheel")

  def visit(body: Body): Unit = println("Moving my Body")

  def visit(engine: Engine): Unit = println("Starting my Engine")

  def visit(car: Car): Unit = println("Starting my Car")
