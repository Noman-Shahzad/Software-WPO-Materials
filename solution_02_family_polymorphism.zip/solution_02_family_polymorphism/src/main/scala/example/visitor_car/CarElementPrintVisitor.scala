package example.visitor_car

case class CarElementPrintVisitor() extends CarElementVisitor:
  override def visit(wheel: Wheel): Unit = println(s"Visiting ${wheel.getName} wheel")

  override def visit(body: Body): Unit = println("Visiting Body")

  override def visit(engine: Engine): Unit = println("Visiting Engine")

  override def visit(car: Car): Unit = println("Visiting Car")
