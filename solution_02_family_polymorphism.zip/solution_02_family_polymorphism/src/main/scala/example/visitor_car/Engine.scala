package example.visitor_car

case class Engine() extends CarElement:
  override def accept(visitor: CarElementVisitor): Unit = visitor.visit(this)
