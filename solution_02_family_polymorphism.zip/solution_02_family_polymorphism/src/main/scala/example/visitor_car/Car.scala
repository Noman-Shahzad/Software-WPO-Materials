package example.visitor_car

class Car extends CarElement:
  val elements: List[CarElement] = List(
    Wheel("front left"), Wheel("front right"),
    Wheel("back left"), Wheel("back right"),
    Body(), Engine()
  )

  override def accept(visitor: CarElementVisitor): Unit =
    elements.foreach(_.accept(visitor))
    visitor.visit(this)
