package example.visitor_car

case class Wheel(name: String) extends CarElement:
  def getName: String = name

  override def accept(visitor: CarElementVisitor): Unit = visitor.visit(this)
