package example.visitor_car

object VisitorDemo extends App {
  private val car: Car = Car()

  car.accept(CarElementPrintVisitor())
  car.accept(CarElementDoVisitor())
}
