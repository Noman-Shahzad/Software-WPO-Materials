package example.visitor_car

trait CarElement:
  def accept(carElementVisitor: CarElementVisitor): Unit
