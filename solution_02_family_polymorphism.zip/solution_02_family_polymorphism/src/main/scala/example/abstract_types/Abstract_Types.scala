package example.abstract_types

trait Buffer:
  type T
  val element: T

abstract class SeqBuffer extends Buffer:
  type U
  type T <: Seq[U]
  def length: Int = element.length

abstract class IntSeqBuffer extends SeqBuffer:
  type U = Int

object Abstract_Types extends App:
  def newIntSeqBuf(elem1: Int, elem2: Int): IntSeqBuffer =
    new IntSeqBuffer:
      type T = List[U]
      val element: List[Int] = List(elem1, elem2)

  val buffer: IntSeqBuffer = newIntSeqBuf(7, 8)
  println("length = " + buffer.length)
  println("content = " + buffer.element)
