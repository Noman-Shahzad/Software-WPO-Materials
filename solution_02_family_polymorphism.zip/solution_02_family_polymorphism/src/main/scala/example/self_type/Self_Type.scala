package example.self_type

trait User:
  def username: String

trait Tweeter:
  this: User =>  // reassign this
  def tweet(tweetText: String): Unit = println(s"$username: $tweetText")

class VerifiedTweeter(val username_ : String) extends Tweeter, User:  // We mixin User because Tweeter required it
  def username = s"real $username_"

object Self extends App:
  val realBeyonce = VerifiedTweeter("Beyoncé")
  realBeyonce.tweet("Just spilled my glass of lemonade")


/**
 * Here are some scenarios where self-types might be more useful:
 *
 * Multiple inheritance: In Scala, you can only extend one class, but you can mix in multiple traits.
 * If you want to mix in multiple traits that require different types, self-types can help you achieve that.
 *
 * Abstract classes: If you have an abstract class that requires a certain type, but you don't want to extend that 
 * class, self-types can help achieve that.
 *
 * Type constraints: Self-types can be used to enforce type constraints on a trait. 
 * For example, if you have a trait that requires a certain type, you can use self-types to ensure that the trait is 
 * only mixed-in with classes that provide that type.
 */
