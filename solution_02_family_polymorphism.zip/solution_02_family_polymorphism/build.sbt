ThisBuild / version := "0.0.1"

ThisBuild / scalaVersion := "3.5.1"

lazy val root = (project in file("."))
  .settings(
    name := "Lab Session 2"
  )
