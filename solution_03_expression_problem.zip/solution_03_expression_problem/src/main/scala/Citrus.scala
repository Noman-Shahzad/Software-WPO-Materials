sealed trait Citrus:
  def mass_g: Double
  def accept[R](visitor: CitrusVisitor[R]): R

final case class Lemon(mass_g: Double, acidity: Double) extends Citrus:
  def accept[R](visitor: CitrusVisitor[R]): R = visitor.visit(this)

final case class Orange(mass_g: Double, sweetnessBrix: Double) extends Citrus:
  def accept[R](visitor: CitrusVisitor[R]): R = visitor.visit(this)

final case class Grapefruit(mass_g: Double, ruby: Boolean) extends Citrus:
  def accept[R](visitor: CitrusVisitor[R]): R = visitor.visit(this)

final case class Yuzu(mass_g: Double, seeds: Int) extends Citrus:
  def accept[R](visitor: CitrusVisitor[R]): R = visitor.visit(this)

final case class Lime(mass_g: Double, tartness: Double) extends Citrus:
  def accept[R](visitor: CitrusVisitor[R]): R = visitor.visit(this)

object VitCTable: // mg per 100g
  val Lemon = 53.0
  val Orange = 53.0
  val Grapefruit = 31.0
  val Yuzu = 40.0
  val Lime = 35.0

// TODO: define the Visitor trait
trait CitrusVisitor[R]:
  def visit(l: Lemon): R
  def visit(o: Orange): R
  def visit(g: Grapefruit): R
  def visit(y: Yuzu): R
  def visit(l: Lime): R

// 1) Implement LabelVisitor : CitrusVisitor[String]
final class LabelVisitor extends CitrusVisitor[String]:
  def visit(l: Lemon): String =
    s"Lemon(${l.mass_g}g, acidity=${l.acidity})"

  def visit(o: Orange): String =
    s"Orange(${o.mass_g}g, brix=${o.sweetnessBrix})"

  def visit(g: Grapefruit): String =
    s"Grapefruit(${g.mass_g}g, ruby=${g.ruby})"

  def visit(y: Yuzu): String =
    s"Yuzu(${y.mass_g}g, seeds=${y.seeds})"

  def visit(l: Lime): String =
    s"Lime(${l.mass_g}g, tartness=${l.tartness})"

// 2) Implement VitaminCVisitor : CitrusVisitor[Double]
final class VitaminCVisitor extends CitrusVisitor[Double]:
  private def calculateVitC(mass: Double, rate: Double): Double =
    mass * rate / 100

  def visit(l: Lemon): Double =
    calculateVitC(l.mass_g, VitCTable.Lemon)

  def visit(o: Orange): Double =
    calculateVitC(o.mass_g, VitCTable.Orange)

  def visit(g: Grapefruit): Double =
    calculateVitC(g.mass_g, VitCTable.Grapefruit)

  def visit(y: Yuzu): Double =
    calculateVitC(y.mass_g, VitCTable.Yuzu)

  def visit(l: Lime): Double =
    calculateVitC(l.mass_g, VitCTable.Lime)

/*
    TEST CODE
 */

val items: List[Citrus] = List(
  Lemon(120, 2.1),
  Orange(150, 11.5),
  Grapefruit(200, ruby = true),
  Yuzu(80, 16)
)

@main def ex1(): Unit =

  val labelV = new LabelVisitor
  val labels = items.map(_.accept(labelV))

  println("— Labels —")
  println(labels.mkString("\n"))

@main def ex2(): Unit =
  val vitCV = new VitaminCVisitor
  val vitCs = items.map(_.accept(vitCV))
  val totalC = vitCs.sum

  println(f"Total vitamin C: $totalC%.1f mg")

@main def ex3(): Unit =
  val lime = new Lime(100, 3.0)
  val labelV = new LabelVisitor
  val vitCV = new VitaminCVisitor
  val label = lime.accept(labelV)
  val vitc = lime.accept(vitCV)

  println(f"${label} has ${vitc}%.1f mg of vitimin C")
