// ----- Model -----
sealed trait Shape:
  def accept[R](visitor: ShapeVisitor[R]): R

final case class Circle(radius: Double) extends Shape:
  def accept[R](visitor: ShapeVisitor[R]): R = visitor.visit(this)

final case class Rectangle(length: Double, width: Double) extends Shape:
  def accept[R](visitor: ShapeVisitor[R]): R = visitor.visit(this)

final case class RightTriangle(base: Double, height: Double) extends Shape:
  def accept[R](visitor: ShapeVisitor[R]): R = visitor.visit(this)

// ----- Visitor trait -----
trait ShapeVisitor[R]:
  def visit(c: Circle): R
  def visit(r: Rectangle): R
  def visit(rt: RightTriangle): R

// ----- Visitors -----

// A) AreaVisitor : Double
final class AreaVisitor extends ShapeVisitor[Double]:
  def visit(c: Circle): Double    = math.Pi * math.pow(c.radius, 2)
  def visit(r: Rectangle): Double = r.length * r.width
  def visit(rt: RightTriangle): Double = 0.5 * rt.base * rt.height

// B) DescribeVisitor : String
final class DescribeVisitor extends ShapeVisitor[String]:
  def visit(c: Circle): String =
    f"Circle(radius = ${c.radius}%.2f)"

  def visit(r: Rectangle): String =
    f"Rectangle(length = ${r.length}%.2f, width = ${r.width}%.2f)"

  def visit(rt: RightTriangle): String =
    f"Right Triangle (base = ${rt.base}%.2f, height = ${rt.height}%.2f)"

// C) PerimeterVisitor : Double
final class PerimeterVisitor extends ShapeVisitor[Double]:
  def visit(c: Circle): Double    = 2.0 * math.Pi * c.radius
  def visit(r: Rectangle): Double = 2.0 * (r.length + r.width)
  def visit(rt: RightTriangle): Double = rt.base + rt.height + math.hypot(rt.base, rt.height)


@main def main(): Unit =
  val shapes: List[Shape] = List(
    Circle(1.0),
    Rectangle(3.0, 4.0),
    RightTriangle(3.0, 4.0)
  )

  val areaV = new AreaVisitor
  val descV = new DescribeVisitor
  val perimeterV = new PerimeterVisitor

  println("=== Shape Report ===")
  for s <- shapes do
    val desc = s.accept(descV)
    val area = s.accept(areaV)
    val per = s.accept(perimeterV)
    println(s"$desc")
    println(f"  Area: $area%.4f m²")
    println(f"  Perimeter: $per%.4f m")
    println()

  val totalArea = shapes.map(_.accept(areaV)).sum
  val totalPer = shapes.map(_.accept(perimeterV)).sum

  println("=== Totals ===")
  println(f"Total area: $totalArea%.4f m²")
  println(f"Total perimeter: $totalPer%.4f m")
