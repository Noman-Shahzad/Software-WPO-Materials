package Basics

case class LabTopic(topic: String)
case class LabTool(tool: String)

object LabGreeter:
  def startSession(student: String)(using LabTopic, LabTool): Unit =
    println(s"Hello, $student! Welcome to today’s lab session.")
    println(s"Our topic is: ${summon[LabTopic].topic}")
    println(s"Please make sure you have your ${summon[LabTool].tool} ready.")

def BobGreeter(): Unit =
    given LabTopic = LabTopic("Scala contextual parameters")
    given LabTool  = LabTool("VS Code with Metals")
    LabGreeter.startSession("Bob")

def AliceGreeter(): Unit =
    given LabTopic = LabTopic("Scala contextual parameters")
    given LabTool  = LabTool("IntelliJ IDEA with Scala plugin")
    LabGreeter.startSession("Alice")


@main def labDemo(): Unit =
    BobGreeter()

    println()

    AliceGreeter()

