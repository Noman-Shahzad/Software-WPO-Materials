package Basics

@main def namedArgumets(): Unit =

    def sumNumbers(first: Int = 1, second: Int = 2) = first + second

    def form(firstName: String = "", middleName: String = "", lastName:String = ""): String =
        s"$firstName $middleName $lastName"

    sumNumbers(first = 5, second = 6)
    form(firstName = "Martin", lastName = "Odersky")