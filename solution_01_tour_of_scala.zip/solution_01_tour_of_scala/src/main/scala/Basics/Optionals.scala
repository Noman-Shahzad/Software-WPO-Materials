package Basics

enum Snack:
  case Chips, Chocolate, Fruit, Cookie

enum Drink:
  case Water, Coke, Lemonade

case class Order(name: String, age: Int, snack: Option[Snack], drink: Option[Drink])

@main def optionals(): Unit =
  val order1 = Order("Alice", 20, Some(Snack.Chocolate), Some(Drink.Coke))
  val order2 = Order("Bob", 23, None, Some(Drink.Lemonade))
  val order3 = Order("Charlie", 19, Some(Snack.Fruit), None)

  val orders = List(order1, order2, order3)

  orders.foreach { f =>
    println(s"--- Order for ${f.name} ---")

    f.snack match
      case Some(s) => println(s"Snack: $s")
      case None    => println("No snack ordered")

    f.drink match
      case Some(t) => println(s"Drink: $t")
      case None    => println("No drink ordered")

    println()
  }
