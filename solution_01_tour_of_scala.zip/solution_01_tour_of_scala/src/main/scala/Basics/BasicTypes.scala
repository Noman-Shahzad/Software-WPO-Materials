// In this first exercise we will intoduce some of the basic types in Scala
//TODO: Complete the expressions in the placeholder assigning the type you deem most appropriate.

@main def BasicTypes(): Unit =
    
    val conditional: Boolean = false

    val number1: Int = 348327487
    val number2: Short = 2894
    val number3: Long = 2349823498293485398L

    val number4: Float = 234.823
    val message: String = "Hello Scala!"
    val letter: Char = 'a'
    