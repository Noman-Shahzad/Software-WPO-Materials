package Basics

sealed trait Notification

case class Email(sender: String, title: String, body: String) extends Notification
case class SMS(caller: String, message: String) extends Notification

def showNotification(notification: Notification): String =
  notification match
    case Email(sender, s"Urgent: $title", _) =>
      s"You got an urgent email from $sender with title: $title"
    case Email(sender, title, _) =>
      s"You got an email from $sender with title: $title"
    case SMS(number, message) =>
      s"You got an SMS from $number! Message: $message"

val someSms = SMS("12345", "Are you there?")
val someEmail = Email("info@vub.be", "New academic year", "Have a great start of your new academic news.")
val someUrgentEmail = Email("info@vub.be", "Urgent: Tuition Fee", "Please pay your tuition fee.")

@main def patternMatching(): Unit =

    println(showNotification(someSms))  

    println(showNotification(someEmail))  

    println(showNotification(someUrgentEmail))