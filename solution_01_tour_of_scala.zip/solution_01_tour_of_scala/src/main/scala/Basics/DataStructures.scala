// TODO: Complete the types marked as ???.
import scala.compiletime.ops.int
import scala.collection.mutable.Queue

@main def dataStructures(): Unit =
    
    // Creation
    val list: List[Int] = List(3, 4, 6, 1, 9, 3)
    val set: Set[Double] = Set(4.6, 2.1, 7.7986, 3.0, 1.9, 2.3)
    val map: Map[String, String] = Map("Belgium" -> "Brussels", "Germany" -> "Berlin", "Spain" -> "Madrid")
    val queue: Queue[Char] = Queue('s', 'c', 'a', 'l', 'a')

    // Addition
    val newList: List[Int] = 8 :: list
    print(newList)
    val newSet: Set[Double] = set + 3.1
    print(newSet)
    val newMap: Map[String, String] = map + ("The Netherlands" -> "Amsterdam")
    print(newMap)
    queue.enqueue('!')
    print(queue)

    // Other cool operations
    val productList: Int = list.product
    print(productList)
    val sumSet: Int = list.sum
    print(sumSet)
    val stringQueue: String = queue.mkString
    print(stringQueue)
    