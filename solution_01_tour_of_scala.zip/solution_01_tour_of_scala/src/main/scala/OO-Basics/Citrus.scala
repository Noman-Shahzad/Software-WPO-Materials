package `OOBasics`

// ---------- Domain ----------
sealed trait Citrus:
  def name: String
  def mass_g: Double          // whole fruit mass
  def diameter_cm: Double     // for zest surface estimate
  def brix: Double            // sugar (sweetness)
  def pH: Double              // acidity

final case class Lemon(mass_g: Double, diameter_cm: Double, brix: Double = 8.5,  pH: Double = 2.3) extends Citrus:
  val name = "Lemon"
final case class Orange(mass_g: Double, diameter_cm: Double, brix: Double = 12.0, pH: Double = 3.5) extends Citrus:
  val name = "Orange"
final case class Lime(mass_g: Double, diameter_cm: Double, brix: Double = 7.0,   pH: Double = 2.4) extends Citrus:
  val name = "Lime"
final case class Grapefruit(mass_g: Double, diameter_cm: Double, brix: Double = 10.0, pH: Double = 3.2) extends Citrus:
  val name = "Grapefruit"
final case class Yuzu(mass_g: Double, diameter_cm: Double, brix: Double = 9.0,   pH: Double = 2.8) extends Citrus:
  val name = "Yuzu"

// Movements (processes)
sealed trait Process
case object Press extends Process
case object Zest  extends Process
case object Blend extends Process

// 3D "products"
final case class Juice(ml: Double, brix: Double, pH: Double)
final case class ZestGrams(grams: Double, aromaIndex: Double)
final case class Smoothie(ml: Double, brix: Double, pH: Double)

// ---------- Transformations ----------
object CitrusLab:

  // simple type-based juice yield (% of mass that becomes juice)
  private def yieldFraction(c: Citrus): Double = c match
    case _: Lemon      => 0.44
    case _: Orange     => 0.50
    case _: Lime       => 0.40
    case _: Grapefruit => 0.45
    case _: Yuzu       => 0.30

  def press(c: Citrus): Juice =
    // assume 1 g ≈ 1 ml juice
    val ml = c.mass_g * yieldFraction(c)
    Juice(ml = ml, brix = c.brix, pH = c.pH)

  def zest(c: Citrus): ZestGrams =
    // surface area of sphere ≈ π * d^2  (same as 4πr^2)
    val area = math.Pi * c.diameter_cm * c.diameter_cm
    val peelThickness = 0.2          // cm
    val peelDensity = 0.6            // g/cm^3 (loose zest)
    val grams = area * peelThickness * peelDensity
    val aroma = grams * (c.brix / 10.0) // aroma proxy
    ZestGrams(grams = grams, aromaIndex = aroma)

  def blend(cs: List[Citrus]): Smoothie =
    val juices = cs.map(press)
    val totalMl = juices.map(_.ml).sum
    val avgBrix = if totalMl == 0 then 0.0
                  else juices.map(j => j.ml * j.brix).sum / totalMl
    val avgPH   = if totalMl == 0 then 7.0
                  else juices.map(j => j.ml * j.pH).sum / totalMl
    Smoothie(ml = totalMl, brix = avgBrix, pH = avgPH)

// ---------- Demo ----------
@main def citrusDemo(): Unit =
  val lemon  = Lemon(mass_g = 120, diameter_cm = 6.0)
  val orange = Orange(mass_g = 180, diameter_cm = 7.5)
  val yuzu   = Yuzu(mass_g = 90,  diameter_cm = 5.5)

  val lemonJuice  = CitrusLab.press(lemon)
  val orangeZest  = CitrusLab.zest(orange)
  val smoothie    = CitrusLab.blend(List(lemon, orange, yuzu))

  println(f"${lemon.name} juice -> ${lemonJuice.ml}%.1f ml, brix=${lemonJuice.brix}%.1f, pH=${lemonJuice.pH}%.1f")
  println(f"${orange.name} zest  -> ${orangeZest.grams}%.2f g, aromaIndex=${orangeZest.aromaIndex}%.2f")
  println(f"Smoothie (lemon+orange+yuzu) -> ${smoothie.ml}%.1f ml, brix=${smoothie.brix}%.2f, pH=${smoothie.pH}%.2f")
