package `OOBasics`

import scala.language.implicitConversions


// --- "Universal measure": Vitamin C milligrams (mg) ---
final case class VitaminC(mg: Double) extends AnyVal

// Average Vitamin C contents (mg per 100 g)
object VitCTable {
  val Lemon      = 53.0
  val Orange     = 53.0
  val Lime       = 29.0
  val Grapefruit = 31.0
  val Yuzu       = 40.0
}

// --- Implicit conversions: citrus -> VitaminC ---
given Conversion[Lemon, VitaminC] =
  lemon => VitaminC(lemon.mass_g * VitCTable.Lemon / 100.0)

given Conversion[Orange, VitaminC] =
  orange => VitaminC(orange.mass_g * VitCTable.Orange / 100.0)

given Conversion[Lime, VitaminC] =
  lime => VitaminC(lime.mass_g * VitCTable.Lime / 100.0)

given Conversion[Grapefruit, VitaminC] =
  g => VitaminC(g.mass_g * VitCTable.Grapefruit / 100.0)

given Conversion[Yuzu, VitaminC] =
  y => VitaminC(y.mass_g * VitCTable.Yuzu / 100.0)

// --- A tiny type class for rounding, passed implicitly ---
trait Rounding { def apply(x: Double): Double }
given defaultRounding: Rounding with
  def apply(x: Double): Double = math.round(x * 100.0) / 100.0   // 2 decimals

// --- The summing method ---
// Multiple parameter lists: (label)(items*)(using Rounding)
def sumVitaminC(label: String)(items: VitaminC*)(using r: Rounding): Double =
  val total = items.map(_.mg).sum
  val rounded = r(total)
  println(s"[$label] Total Vitamin C = $rounded mg")
  rounded

@main def citrusVitaminCDemo(): Unit =
  sumVitaminC("Morning smoothie")(
    Lemon(mass_g = 120, diameter_cm = 6.2, brix = 8.5, pH = 2.3),
    Orange(mass_g = 150, diameter_cm = 7.8, brix = 9.2, pH = 3.3),
    Lime(mass_g = 80,  diameter_cm = 5.1, brix = 7.8, pH = 2.2),
    Yuzu(mass_g = 90,  diameter_cm = 6.0, brix = 8.0, pH = 2.6)
  )

  sumVitaminC("Afternoon batch")(
    Grapefruit(mass_g = 200, diameter_cm = 9.5, brix = 8.8, pH = 3.1),
    Orange(mass_g = 100, diameter_cm = 7.0, brix = 9.0, pH = 3.3),
    Lemon(mass_g = 70,  diameter_cm = 5.5, brix = 8.2, pH = 2.3)
  )

  // This one mixes a raw VitaminC value with an actual fruit:
  sumVitaminC("Custom add-ons")(
    VitaminC(100.0),
    Lemon(mass_g = 50, diameter_cm = 4.8, brix = 8.1, pH = 2.3)
  )
