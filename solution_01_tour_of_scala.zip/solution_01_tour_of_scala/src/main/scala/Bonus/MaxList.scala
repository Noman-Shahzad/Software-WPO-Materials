package Bonus

def maximumValue(numbers: List[Int]): Int = numbers match
  case Nil => throw new NoSuchElementException("Empty list")
  case head :: Nil => head
  case _ => numbers.max


@main def testMax(): Unit =
  println(maximumValue(List(5)))            // 5
  println(maximumValue(List(3, 8, 2, 7)))   // 8
  println(maximumValue(List()))             // Exception