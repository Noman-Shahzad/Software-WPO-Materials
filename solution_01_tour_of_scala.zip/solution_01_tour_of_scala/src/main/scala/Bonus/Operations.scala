package Bonus

import scala.util.Random


@main def mainMethodEx4(): Unit =
    val numbers = List(5, 3, 7, 1, 4)

    val multiplyFunction = (elements: List[Int]) => elements.product
    val sumFunction = (elements: List[Int]) => elements.sum
    val reducFunction = (elements: List[Int]) => elements.reduce(_ - _)

    val limit = 10

    val orders = Random.shuffle(List(1,2,3))

    val randomOrderOperations: Map[Int, (List[Int] => Int)] = Map(
        orders(0) -> multiplyFunction,
        orders(1) -> sumFunction,
        orders(2) -> reducFunction
        )

    val sortedKeys = randomOrderOperations.keys.toList.sorted
    val sortedOperations = sortedKeys.map(key => randomOrderOperations(key))

    val appliedFunctions = sortedOperations.map(operation => operation(numbers))
    
    println(appliedFunctions.mkString(" "))
