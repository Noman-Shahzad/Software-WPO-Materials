package FunctionalBasics

@main def minMaxList(): Unit =

    // Functional style
    def getMinMax(list: List[Int]): (Int, Int) =
        (list.min, list.max)

    // Imperative style
    def minMax(values: List[Int]): (Int, Int) = 

        var i = 1
        var min = values.head
        var max = values.head

        while (i < values.length) 
            val v = values(i)
            if (v < min) min = v
            if (v > max) max = v
            i += 1

        (min, max)
        
    val numbers = List(3, 1, 7, 2, 5)
    val (max, min) = getMinMax(numbers)
    println(s"Max: $max, Min: $min")

