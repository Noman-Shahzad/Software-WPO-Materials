package FunctionalBasics

@main def swap(): Unit =

  def swapAdjacentElement(words: Array[String]): String =
    // remove duplicates (keep first occurrences)
    val unique = words.distinct

    // swap adjacent elements
    val swapped =
      unique.grouped(2).flatMap {
        case Array(a, b) => Array(b, a) // swap pair
        case Array(a)    => Array(a)    // last odd element stays
      }.toArray

    // Another alternative
    //val swapped2 = unique.grouped(2).flatMap(_.reverse)

    // join with spaces
    swapped.mkString(" ")

  val input = Array("Scala", "is", "fun", "fun", "and", "powerful")
  println("Input:  " + input.mkString(" "))
  val result = swapAdjacentElement(input)
  println("Output: " + result)
