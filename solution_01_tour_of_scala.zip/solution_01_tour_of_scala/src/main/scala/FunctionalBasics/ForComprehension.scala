// TODO: Complete the expressions marked as ???.

@main def PasswordCracker(): Unit =

    def passwordCombinations(number: Int = 5, letter: Char = 'F'): IndexedSeq[(Int, String, Int)] =
    for
        i <- 1 to number
        j <- 'A' to letter
        k <- 1 to number
    yield (i, j.toString, k)

    val combinations = passwordCombinations()
    val numberOfCombinations = combinations.length
    println(s"There are $numberOfCombinations possible combinations: $combinations")

